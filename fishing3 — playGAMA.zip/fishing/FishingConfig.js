// Конфигурация механики рыбалки

const FISHING_CONFIG = {
    // Состояния игры
    STATES: {
        IDLE: 'idle',
        CASTING: 'casting',
        WAITING: 'waiting',
        BITE: 'bite',
        HOOKING: 'hooking',
        REELING: 'reeling',
        RESULT: 'result'
    },
    
    // Настройки заброса
    CAST: {
        DURATION: 0.6,           // Длительность анимации заброса (сек)
        BOBBER_FALL_SPEED: 800,  // Скорость падения поплавка
        MIN_DISTANCE: 100,       // Минимальная дистанция заброса
        MAX_DISTANCE: 500        // Максимальная дистанция
    },
    
    // Настройки ожидания поклёвки
    WAITING: {
        MIN_TIME: 2.0,           // Минимальное время ожидания (сек)
        MAX_TIME: 8.0,           // Максимальное время ожидания
        BOBBER_WOBBLE_SPEED: 1.4,  // Скорость покачивания поплавка (уменьшено на 30%)
        BOBBER_WOBBLE_AMOUNT: 2.1  // Амплитуда покачивания (уменьшено на 30%)
    },
    
    // Настройки поклёвки
    BITE: {
        DURATION: 1.5,           // Время на подсечку (сек)
        BOBBER_DIP_AMOUNT: 15,   // Глубина погружения поплавка
        BOBBER_DIP_SPEED: 8      // Скорость погружения
    },
    
    // Настройки вываживания
    REELING: {
        SPEED: 80,               // Скорость подтягивания (пикс/сек)
        TENSION_DECAY: 0.3,      // Замедление при отпускании
        LINE_TENSION_MAX: 100,   // Максимальное натяжение лески
        FISH_RESISTANCE: 0.4,    // Сопротивление рыбы (0-1)
        BREAK_TENSION: 0.9       // Порог разрыва лески (0-1)
    },
    
    // Визуальные настройки
    VISUALS: {
        WATER_COLOR: '#1e90aa',
        WATER_DEEP_COLOR: '#0d5c6e',
        SKY_COLOR: '#87ceeb',
        LINE_COLOR: '#2ecc71',
        LINE_WIDTH: 2,
        BOBBER_SIZE: 12,
        BOBBER_COLOR: '#e74c3c',
        ROD_COLOR: '#2c3e50'
    },
    
    // Зона воды (относительные координаты 0-1)
    WATER_ZONE: {
        TOP: 0.50,               // Верхняя граница воды (середина экрана)
        BOTTOM: 0.85             // Нижняя граница
    },
    
    // UI элементы
    UI: {
        HOOK_BUTTON_SIZE: 200, // Увеличено в 2 раза (было 100)
        REEL_BUTTON_SIZE: 240, // Увеличено в 2 раза (было 120)
        BUTTON_MARGIN: 30
    }
};

// Данные о рыбах
const FISH_DATA = [
    // Начальные рыбки (легко ловить, маленькая награда)
    { id: 'perch', name: 'Окунь', weight: [0.1, 0.4], price: 5, rarity: 0.6, resistance: 0.15, image: '🐟' },
    { id: 'roach', name: 'Плотва', weight: [0.1, 0.3], price: 3, rarity: 0.7, resistance: 0.12, image: '🐠' },
    
    // Средние рыбы (требуют немного опыта)
    { id: 'carp', name: 'Карп', weight: [0.5, 2], price: 15, rarity: 0.35, resistance: 0.3, image: '🐠' },
    { id: 'pike', name: 'Щука', weight: [1, 4], price: 30, rarity: 0.2, resistance: 0.45, image: '🐡' },
    { id: 'trout', name: 'Форель', weight: [0.5, 1.5], price: 25, rarity: 0.15, resistance: 0.35, image: '🐠' },
    
    // Сложные рыбы (требуют хорошее снаряжение)
    { id: 'catfish', name: 'Сом', weight: [3, 12], price: 60, rarity: 0.08, resistance: 0.65, image: '🐙' },
    { id: 'sturgeon', name: 'Осётр', weight: [5, 20], price: 100, rarity: 0.03, resistance: 0.75, image: '🐋' }
];
