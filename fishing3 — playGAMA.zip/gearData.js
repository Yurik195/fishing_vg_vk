// -*- coding: utf-8 -*-
// База данных снастей: удочки, лески, поплавки, крючки, катушки
// Всего 18 уровней (тиров) для каждого типа снастей

// ============= УДОЧКИ (RODS) =============
const RODS_DATABASE = [
  { tier: 1, name: "Удочка Палка", powerCap: 10, accuracy: 2, hookWindowBonus: 1, castBonus: 1, maxWeight: 0.82, durability: 40, price: 220, sprite: "udchk0.png", emoji: "🎣", description: "Простая удочка для начинающих рыболовов. Подходит для ловли мелкой рыбы в спокойных водах. Уровень 1." },
  { tier: 2, name: "Удочка Тростник", powerCap: 15, accuracy: 2, hookWindowBonus: 1, castBonus: 2, maxWeight: 3.5, durability: 51, price: 976, sprite: "rod_02.png", emoji: "🎣", description: "Лёгкая удочка из тростника для частых забросов. Обеспечивает базовый контроль при вываживании. Уровень 2." },
  { tier: 3, name: "Удочка Стеклопластик", powerCap: 20, accuracy: 3, hookWindowBonus: 1, castBonus: 2, maxWeight: 5.0, durability: 62, price: 2335, sprite: "rod_03.png", emoji: "🎣", description: "Удочка из стеклопластика с улучшенной чувствительностью. Подходит для ловли рыбы средних размеров. Уровень 3." },
  { tier: 4, name: "Удочка Матчевая", powerCap: 35, accuracy: 4, hookWindowBonus: 2, castBonus: 4, maxWeight: 12.0, durability: 94, price: 39, currency: "iap", sprite: "rod_04.png", emoji: "🎣", description: "Удочка премиального качества с превосходной мощностью и точностью. Отличный контроль при дальних забросах и вываживании крупной рыбы." },
  { tier: 5, name: "Удочка Карбон", powerCap: 30, accuracy: 3, hookWindowBonus: 2, castBonus: 3, maxWeight: 9.0, durability: 83, price: 7002, sprite: "rod_05.png", emoji: "🎣", description: "Карбоновая удочка с отличной чувствительностью. Подходит для ловли осторожной рыбы на средних дистанциях. Уровень 5." },
  { tier: 6, name: "Удочка Фидер", powerCap: 35, accuracy: 4, hookWindowBonus: 2, castBonus: 4, maxWeight: 12.0, durability: 94, price: 10362, sprite: "rod_06.png", emoji: "🎣", description: "Фидерная удочка для донной ловли. Мощная и надёжная, подходит для крупной рыбы. Уровень 6." },
  { tier: 7, name: "Удочка Спиннинг", powerCap: 40, accuracy: 4, hookWindowBonus: 2, castBonus: 4, maxWeight: 15.0, durability: 105, price: 14434, sprite: "rod_07.png", emoji: "🎣", description: "Спиннинговая удочка для активной ловли хищника. Обеспечивает точные забросы и хороший контроль. Уровень 7." },
  { tier: 8, name: "Удочка Спиннинг Heavy", powerCap: 45, accuracy: 4, hookWindowBonus: 3, castBonus: 5, maxWeight: 18.0, durability: 115, price: 19234, sprite: "rod_08.png", emoji: "🎣", description: "Тяжёлый спиннинг для ловли крупного хищника. Мощная конструкция выдерживает сильные рывки. Уровень 8." },
  { tier: 9, name: "Удочка Карповая", powerCap: 60, accuracy: 5, hookWindowBonus: 3, castBonus: 6, maxWeight: 35.0, durability: 148, price: 79, currency: "iap", sprite: "rod_09.png", emoji: "🎣", description: "Удочка премиального качества повышенной мощности. Специально разработана для трофейной ловли с максимальной надёжностью при вываживании." },
  { tier: 10, name: "Удочка Тропик Heavy", powerCap: 55, accuracy: 5, hookWindowBonus: 3, castBonus: 6, maxWeight: 28.0, durability: 137, price: 35737, sprite: "rod_10.png", emoji: "🎣", description: "Тяжёлая удочка для тропической рыбалки. Выдерживает мощные рывки крупной морской рыбы. Уровень 10." },
  { tier: 11, name: "Удочка Морской берег", powerCap: 60, accuracy: 5, hookWindowBonus: 3, castBonus: 6, maxWeight: 35.0, durability: 148, price: 43865, sprite: "rod_11.png", emoji: "🎣", description: "Удочка для морской береговой ловли. Обеспечивает дальние забросы и контроль крупной рыбы. Уровень 11." },
  { tier: 12, name: "Удочка Boat Heavy", powerCap: 65, accuracy: 6, hookWindowBonus: 4, castBonus: 7, maxWeight: 45.0, durability: 159, price: 52888, sprite: "rod_12.png", emoji: "🎣", description: "Тяжёлая лодочная удочка для морской рыбалки. Мощная конструкция для вываживания крупных хищников. Уровень 12." },
  { tier: 13, name: "Удочка Boat X-Heavy", powerCap: 70, accuracy: 6, hookWindowBonus: 4, castBonus: 7, maxWeight: 55.0, durability: 169, price: 62820, sprite: "rod_13.png", emoji: "🎣", description: "Сверхтяжёлая лодочная удочка для крупной морской рыбы. Выдерживает экстремальные нагрузки. Уровень 13." },
  { tier: 14, name: "Удочка Троллинг Pro", powerCap: 85, accuracy: 7, hookWindowBonus: 5, castBonus: 9, maxWeight: 120.0, durability: 202, price: 99, currency: "iap", sprite: "rod_14.png", emoji: "🎣", description: "Легендарная удочка премиального качества. Непревзойдённая мощность и точность для океанической рыбалки и крупнейших хищников." },
  { tier: 15, name: "Удочка Троллинг X-Pro", powerCap: 80, accuracy: 7, hookWindowBonus: 4, castBonus: 8, maxWeight: 90.0, durability: 191, price: 85451, sprite: "rod_15.png", emoji: "🎣", description: "Экстра-профессиональная троллинговая удочка. Максимальная мощность для трофейной морской рыбалки. Уровень 15." },
  { tier: 16, name: "Удочка Ocean Pro", powerCap: 85, accuracy: 7, hookWindowBonus: 5, castBonus: 9, maxWeight: 120.0, durability: 202, price: 98170, sprite: "rod_16.png", emoji: "🎣", description: "Профессиональная океаническая удочка. Выдерживает длительное вываживание крупнейших морских хищников. Уровень 16." },
  { tier: 17, name: "Удочка Ocean Titan", powerCap: 95, accuracy: 8, hookWindowBonus: 5, castBonus: 10, maxWeight: 220.0, durability: 223, price: 119, currency: "iap", sprite: "rod_17.png", emoji: "🎣", description: "Легендарная удочка премиального качества. Максимальная мощность и непревзойдённая точность для величайших трофеев океана." },
  { tier: 18, name: "Удочка Sharkmaster", powerCap: 95, accuracy: 8, hookWindowBonus: 5, castBonus: 10, maxWeight: 220.0, durability: 223, price: 126461, sprite: "rod_18.png", emoji: "🎣", description: "Легендарная удочка для ловли акул. Непревзойдённая мощность для величайших трофеев океана до 220 кг. Уровень 18." }
];

// ============= ЛЕСКИ (LINES) =============
const LINES_DATABASE = [
  { tier: 1, name: "Леска Монофил 0.18", type: "Моно", testKg: 0.82, abrasionResist: 2, durability: 40, price: 121, sprite: "line_01.png", emoji: "🧵", description: "Базовая монофильная леска для начинающих. Достаточная прочность для мелкой рыбы. Уровень 1." },
  { tier: 2, name: "Леска Монофил 0.22", type: "Моно", testKg: 3.5, abrasionResist: 2, durability: 51, price: 537, sprite: "line_02.png", emoji: "🧵", description: "Улучшенная монофильная леска. Повышенная надёжность для рыбы средних размеров. Уровень 2." },
  { tier: 3, name: "Леска Флюорокарбон 0.25", type: "Флюр/Моно", testKg: 5.0, abrasionResist: 2, durability: 62, price: 1284, sprite: "line_03.png", emoji: "🧵", description: "Флюорокарбоновая леска с хорошей устойчивостью к истиранию. Менее заметна в воде. Уровень 3." },
  { tier: 4, name: "Леска Флюорокарбон 0.28", type: "Флюр/Моно", testKg: 12.0, abrasionResist: 3, durability: 94, price: 39, currency: "iap", sprite: "line_04.png", emoji: "🧵", description: "Леска премиального качества с превосходной прочностью. Отличная устойчивость к истиранию и надёжность при вываживании крупной рыбы." },
  { tier: 5, name: "Леска Плетёнка PE 1.0", type: "Плетёнка", testKg: 9.0, abrasionResist: 3, durability: 83, price: 3851, sprite: "line_05.png", emoji: "🧵", description: "Плетёная леска с высокой прочностью. Минимальное растяжение для лучшего контроля. Уровень 5." },
  { tier: 6, name: "Леска Плетёнка PE 1.5", type: "Плетёнка", testKg: 12.0, abrasionResist: 3, durability: 94, price: 5699, sprite: "line_06.png", emoji: "🧵", description: "Качественная плетёная леска. Отличная устойчивость к рывкам и истиранию. Уровень 6." },
  { tier: 7, name: "Леска Плетёнка PE 2.0", type: "Плетёнка", testKg: 15.0, abrasionResist: 3, durability: 105, price: 7939, sprite: "line_07.png", emoji: "🧵", description: "Прочная плетёная леска для крупной рыбы. Высокая надёжность при длительном вываживании. Уровень 7." },
  { tier: 8, name: "Леска Плетёнка PE 2.5", type: "Плетёнка", testKg: 18.0, abrasionResist: 4, durability: 115, price: 10579, sprite: "line_08.png", emoji: "🧵", description: "Усиленная плетёная леска. Выдерживает мощные рывки хищника. Уровень 8." },
  { tier: 9, name: "Леска Плетёнка PE 3.0", type: "Плетёнка", testKg: 22.0, abrasionResist: 4, durability: 127, price: 13627, sprite: "line_09.png", emoji: "🧵", description: "Профессиональная плетёная леска. Максимальная прочность для трофейной рыбалки. Уровень 9." },
  { tier: 10, name: "Леска Морская PE 4.0", type: "Плетёнка", testKg: 45.0, abrasionResist: 5, durability: 159, price: 69, currency: "iap", sprite: "line_10.png", emoji: "🧵", description: "Леска премиального качества повышенной прочности. Специально разработана для морской рыбалки с максимальной устойчивостью к нагрузкам." },
  { tier: 11, name: "Леска Морская PE 5.0", type: "Плетёнка", testKg: 35.0, abrasionResist: 4, durability: 148, price: 24126, sprite: "line_11.png", emoji: "🧵", description: "Прочная морская леска. Надёжна при ловле крупных морских хищников. Уровень 11." },
  { tier: 12, name: "Леска Морская PE 6.0", type: "Плетёнка", testKg: 45.0, abrasionResist: 5, durability: 159, price: 29088, sprite: "line_12.png", emoji: "🧵", description: "Усиленная морская леска. Выдерживает экстремальные нагрузки при вываживании. Уровень 12." },
  { tier: 13, name: "Леска Морская PE 8.0", type: "Плетёнка", testKg: 55.0, abrasionResist: 5, durability: 169, price: 34551, sprite: "line_13.png", emoji: "🧵", description: "Сверхпрочная морская леска. Максимальная устойчивость к рывкам и истиранию. Уровень 13." },
  { tier: 14, name: "Леска Океан PE 10", type: "Плетёнка", testKg: 70.0, abrasionResist: 5, durability: 181, price: 40519, sprite: "line_14.png", emoji: "🧵", description: "Профессиональная океаническая леска. Выдерживает длительную борьбу с крупной рыбой. Уровень 14." },
  { tier: 15, name: "Леска Океан PE 12", type: "Плетёнка", testKg: 160.0, abrasionResist: 6, durability: 213, price: 99, currency: "iap", sprite: "line_15.png", emoji: "🧵", description: "Легендарная леска премиального качества. Непревзойдённая прочность и устойчивость к истиранию для экстремальной океанической рыбалки." },
  { tier: 16, name: "Леска Титан PE 15", type: "Плетёнка", testKg: 120.0, abrasionResist: 6, durability: 202, price: 53994, sprite: "line_16.png", emoji: "🧵", description: "Титановая плетёная леска. Непревзойдённая прочность для крупнейших хищников. Уровень 16." },
  { tier: 17, name: "Леска Титан PE 20", type: "Плетёнка", testKg: 160.0, abrasionResist: 6, durability: 213, price: 61510, sprite: "line_17.png", emoji: "🧵", description: "Легендарная океаническая леска. Максимальная надёжность для экстремальной рыбалки. Уровень 17." },
  { tier: 18, name: "Леска Акула PE 30", type: "Плетёнка", testKg: 220.0, abrasionResist: 6, durability: 223, price: 69554, sprite: "line_18.png", emoji: "🧵", description: "Непревзойдённая леска для ловли акул. Выдерживает величайшие нагрузки до 220 кг. Уровень 18." }
];

// ============= ПОПЛАВКИ (FLOATS) =============
const FLOATS_DATABASE = [
  { tier: 1, name: "Поплавок Гусиное перо", sensitivity: 2, stability: 3, durability: 40, price: 77, sprite: "float_01.png", emoji: "🎈", description: "Простой поплавок для спокойной воды. Базовая чувствительность к поклёвкам. Уровень 1." },
  { tier: 2, name: "Поплавок Бальса", sensitivity: 3, stability: 4, durability: 51, price: 342, sprite: "float_02.png", emoji: "🎈", description: "Улучшенный поплавок с хорошей чувствительностью. Стабилен на лёгкой волне. Уровень 2." },
  { tier: 3, name: "Поплавок Веретено", sensitivity: 4, stability: 5, durability: 73, price: 39, currency: "iap", sprite: "float_03.png", emoji: "🎈", description: "Поплавок премиального качества с высокой чувствительностью. Отлично подходит для точной ловли осторожной рыбы." },
  { tier: 4, name: "Поплавок Карандаш", sensitivity: 4, stability: 5, durability: 73, price: 1517, sprite: "float_04.png", emoji: "🎈", description: "Поплавок с высокой чувствительностью. Стабилен на умеренной волне и течении. Уровень 4." },
  { tier: 5, name: "Поплавок Ваглер", sensitivity: 4, stability: 5, durability: 83, price: 2451, sprite: "float_05.png", emoji: "🎈", description: "Качественный поплавок для точной ловли. Отличная чувствительность к осторожным поклёвкам. Уровень 5." },
  { tier: 6, name: "Поплавок Стик", sensitivity: 5, stability: 6, durability: 94, price: 3627, sprite: "float_06.png", emoji: "🎈", description: "Профессиональный поплавок с высокой чувствительностью. Стабилен на волне и течении. Уровень 6." },
  { tier: 7, name: "Поплавок Матчевый", sensitivity: 6, stability: 7, durability: 115, price: 69, currency: "iap", sprite: "float_07.png", emoji: "🎈", description: "Поплавок премиального качества для профессиональной ловли. Превосходная чувствительность и стабильность в сложных условиях." },
  { tier: 8, name: "Поплавок Болонский", sensitivity: 6, stability: 7, durability: 115, price: 6732, sprite: "float_08.png", emoji: "🎈", description: "Усиленный поплавок с отличной чувствительностью. Стабилен в сложных условиях. Уровень 8." },
  { tier: 9, name: "Поплавок Маховый Pro", sensitivity: 6, stability: 7, durability: 127, price: 8672, sprite: "float_09.png", emoji: "🎈", description: "Профессиональный поплавок для трофейной ловли. Высокая чувствительность и стабильность. Уровень 9." },
  { tier: 10, name: "Поплавок Морской Дрифтер", sensitivity: 7, stability: 8, durability: 137, price: 12508, sprite: "float_10.png", emoji: "🎈", description: "Морской поплавок с высокой стабильностью. Чувствителен даже на волне. Уровень 10." },
  { tier: 11, name: "Поплавок Сёрф", sensitivity: 7, stability: 8, durability: 148, price: 15353, sprite: "float_11.png", emoji: "🎈", description: "Прочный морской поплавок. Стабилен в условиях морской волны и течения. Уровень 11." },
  { tier: 12, name: "Поплавок Пилькер", sensitivity: 8, stability: 9, durability: 159, price: 18511, sprite: "float_12.png", emoji: "🎈", description: "Усиленный морской поплавок. Максимальная чувствительность и стабильность на волне. Уровень 12." },
  { tier: 13, name: "Поплавок Слайдер", sensitivity: 8, stability: 9, durability: 169, price: 21987, sprite: "float_13.png", emoji: "🎈", description: "Профессиональный морской поплавок. Надёжен в сложных морских условиях. Уровень 13." },
  { tier: 14, name: "Поплавок Океанский Дрифт", sensitivity: 9, stability: 10, durability: 181, price: 25785, sprite: "float_14.png", emoji: "🎈", description: "Океанический поплавок с максимальной чувствительностью. Стабилен на сильной волне. Уровень 14." },
  { tier: 15, name: "Поплавок Пелагический", sensitivity: 9, stability: 10, durability: 191, price: 29908, sprite: "float_15.png", emoji: "🎈", description: "Экстра-чувствительный океанический поплавок. Надёжен в экстремальных условиях. Уровень 15." },
  { tier: 16, name: "Поплавок Титан", sensitivity: 10, stability: 10, durability: 223, price: 109, currency: "iap", sprite: "float_16.png", emoji: "🎈", description: "Легендарный поплавок премиального качества. Непревзойдённая чувствительность и максимальная стабильность для океанической рыбалки." },
  { tier: 17, name: "Поплавок Океан Мастер", sensitivity: 10, stability: 10, durability: 213, price: 39143, sprite: "float_17.png", emoji: "🎈", description: "Легендарный океанический поплавок. Идеальная чувствительность и стабильность. Уровень 17." },
  { tier: 18, name: "Поплавок Шторм Кинг", sensitivity: 10, stability: 10, durability: 223, price: 44261, sprite: "float_18.png", emoji: "🎈", description: "Непревзойдённый поплавок для экстремальной рыбалки. Максимальные характеристики. Уровень 18." }
];

// ============= КРЮЧКИ (HOOKS) =============
// maxWeight - максимальный вес рыбы (кг), при превышении увеличивается износ
const HOOKS_DATABASE = [
  { tier: 1, name: "Крючок Одинарный", holdBonus: 2, penetration: 2, hookSize: 14, maxWeight: 0.82, durability: 40, price: 99, sprite: "hook_01.png", emoji: "🪝", description: "Простой крючок для мелкой рыбы. Базовая надёжность подсечки и удержания. Размер №14. Уровень 1." },
  { tier: 2, name: "Крючок Одинарный Pro", holdBonus: 3, penetration: 2, hookSize: 13, maxWeight: 3.5, durability: 51, price: 439, sprite: "hook_02.png", emoji: "🪝", description: "Улучшенный крючок с хорошей проникающей способностью. Надёжно держит рыбу средних размеров. Размер №13. Уровень 2." },
  { tier: 3, name: "Крючок Лещовый", holdBonus: 3, penetration: 3, hookSize: 13, maxWeight: 5.0, durability: 62, price: 1051, sprite: "hook_03.png", emoji: "🪝", description: "Острый крючок для уверенной подсечки. Хорошо держит осторожную рыбу. Размер №13. Уровень 3." },
  { tier: 4, name: "Крючок Карповый", holdBonus: 5, penetration: 4, hookSize: 11, maxWeight: 12.0, durability: 94, price: 49, currency: "iap", sprite: "hook_04.png", emoji: "🪝", description: "Крючок премиального качества с превосходной проникающей способностью и надёжностью. Идеален для ловли крупной рыбы. Размер №11." },
  { tier: 5, name: "Крючок Фидерный", holdBonus: 4, penetration: 3, hookSize: 12, maxWeight: 9.0, durability: 83, price: 3151, sprite: "hook_05.png", emoji: "🪝", description: "Прочный крючок для трофейной ловли. Уверенная подсечка и надёжное удержание. Размер №12. Уровень 5." },
  { tier: 6, name: "Крючок Офсетный", holdBonus: 5, penetration: 4, hookSize: 11, maxWeight: 12.0, durability: 94, price: 4663, sprite: "hook_06.png", emoji: "🪝", description: "Профессиональный крючок с высокой прочностью. Отлично держит крупную рыбу. Размер №11. Уровень 6." },
  { tier: 7, name: "Крючок Тройник", holdBonus: 5, penetration: 4, hookSize: 11, maxWeight: 15.0, durability: 105, price: 6495, sprite: "hook_07.png", emoji: "🪝", description: "Усиленный крючок для мощной рыбы. Максимальная проникающая способность. Размер №11. Уровень 7." },
  { tier: 8, name: "Крючок Хищник", holdBonus: 7, penetration: 5, hookSize: 9, maxWeight: 28.0, durability: 137, price: 79, currency: "iap", sprite: "hook_08.png", emoji: "🪝", description: "Крючок премиального качества повышенной прочности. Специально разработан для морской рыбалки и крупных хищников. Размер №9." },
  { tier: 9, name: "Крючок Тройник Pro", holdBonus: 6, penetration: 5, hookSize: 10, maxWeight: 22.0, durability: 127, price: 11150, sprite: "hook_09.png", emoji: "🪝", description: "Профессиональный крючок для трофейной рыбалки. Непревзойдённая надёжность. Размер №10. Уровень 9." },
  { tier: 10, name: "Крючок Морской", holdBonus: 7, penetration: 5, hookSize: 9, maxWeight: 28.0, durability: 137, price: 16082, sprite: "hook_10.png", emoji: "🪝", description: "Морской крючок с высокой прочностью. Отлично держит крупную морскую рыбу. Размер №9. Уровень 10." },
  { tier: 11, name: "Крючок Сёрф", holdBonus: 7, penetration: 5, hookSize: 9, maxWeight: 35.0, durability: 148, price: 19739, sprite: "hook_11.png", emoji: "🪝", description: "Усиленный морской крючок. Надёжен для мощных морских хищников. Размер №9. Уровень 11." },
  { tier: 12, name: "Крючок Джиг", holdBonus: 8, penetration: 6, hookSize: 8, maxWeight: 45.0, durability: 159, price: 23800, sprite: "hook_12.png", emoji: "🪝", description: "Прочный морской крючок. Уверенная подсечка даже твёрдой пасти. Размер №8. Уровень 12." },
  { tier: 13, name: "Крючок Троллинг", holdBonus: 8, penetration: 6, hookSize: 8, maxWeight: 55.0, durability: 169, price: 28269, sprite: "hook_13.png", emoji: "🪝", description: "Сверхпрочный морской крючок. Максимальная надёжность при экстремальных нагрузках. Размер №8. Уровень 13." },
  { tier: 14, name: "Крючок Океан", holdBonus: 9, penetration: 6, hookSize: 7, maxWeight: 70.0, durability: 181, price: 33152, sprite: "hook_14.png", emoji: "🪝", description: "Профессиональный океанический крючок. Выдерживает длительную борьбу с крупной рыбой. Размер №7. Уровень 14." },
  { tier: 15, name: "Крючок Марлин", holdBonus: 9, penetration: 7, hookSize: 7, maxWeight: 90.0, durability: 191, price: 38453, sprite: "hook_15.png", emoji: "🪝", description: "Экстра-прочный океанический крючок. Непревзойдённая проникающая способность. Размер №7. Уровень 15." },
  { tier: 16, name: "Крючок Тунец", holdBonus: 10, penetration: 7, hookSize: 6, maxWeight: 120.0, durability: 202, price: 44176, sprite: "hook_16.png", emoji: "🪝", description: "Титановый крючок для крупнейших хищников. Максимальная прочность и надёжность. Размер №6. Уровень 16." },
  { tier: 17, name: "Крючок Меч-рыба", holdBonus: 10, penetration: 8, hookSize: 5, maxWeight: 250.0, durability: 235, price: 119, currency: "iap", sprite: "hook_17.png", emoji: "🪝", description: "Легендарный крючок премиального качества. Непревзойдённая прочность и проникающая способность для трофейной океанической рыбалки. Размер №5." },
  { tier: 18, name: "Крючок Акула", holdBonus: 10, penetration: 8, hookSize: 5, maxWeight: 220.0, durability: 223, price: 56907, sprite: "hook_18.png", emoji: "🪝", description: "Непревзойдённый крючок для ловли акул. Максимальная прочность и проникающая способность. Размер №5. Уровень 18." }
];

// ============= КАТУШКИ (REELS) =============
const REELS_DATABASE = [
  { tier: 1, name: "Катушка Базовая", dragKg: 0.82, retrieveSpeed: 2, smoothness: 3, durability: 40, price: 176, sprite: "h1.png", emoji: "⚙️", description: "Простая катушка для начинающих. Базовая плавность работы и контроль рывков. Уровень 1." },
  { tier: 2, name: "Катушка Стандарт", dragKg: 2.2, retrieveSpeed: 3, smoothness: 4, durability: 51, price: 781, sprite: "h2.png", emoji: "⚙️", description: "Улучшенная катушка с хорошей плавностью хода. Надёжна для рыбы средних размеров. Уровень 2." },
  { tier: 3, name: "Катушка Комфорт", dragKg: 4.3, retrieveSpeed: 4, smoothness: 5, durability: 73, price: 39, currency: "iap", sprite: "h3.png", emoji: "⚙️", description: "Катушка премиального качества с превосходной плавностью хода. Отличный контроль рывков и надёжность при вываживании крупной рыбы." },
  { tier: 4, name: "Катушка Спорт", dragKg: 4.3, retrieveSpeed: 4, smoothness: 5, durability: 73, price: 3467, sprite: "h4.png", emoji: "⚙️", description: "Катушка с отличной плавностью хода. Надёжный контроль рывков крупной рыбы. Уровень 4." },
  { tier: 5, name: "Катушка Профи", dragKg: 5.8, retrieveSpeed: 4, smoothness: 5, durability: 83, price: 5602, sprite: "h5.png", emoji: "⚙️", description: "Профессиональная катушка с высокой плавностью. Подходит для длительного вываживания. Уровень 5." },
  { tier: 6, name: "Катушка Мастер", dragKg: 7.2, retrieveSpeed: 5, smoothness: 6, durability: 94, price: 8290, sprite: "h6.png", emoji: "⚙️", description: "Усиленная катушка с отличным контролем. Плавная работа при мощных рывках. Уровень 6." },
  { tier: 7, name: "Катушка Эксперт", dragKg: 9.0, retrieveSpeed: 5, smoothness: 6, durability: 105, price: 11547, sprite: "h7.png", emoji: "⚙️", description: "Прочная катушка для трофейной ловли. Максимальная плавность и контроль. Уровень 7." },
  { tier: 8, name: "Катушка Турнир", dragKg: 13.7, retrieveSpeed: 7, smoothness: 8, durability: 137, price: 79, currency: "iap", sprite: "h8.png", emoji: "⚙️", description: "Катушка премиального качества повышенной мощности. Специально разработана для морской рыбалки с максимальным контролем при вываживании." },
  { tier: 9, name: "Катушка Чемпион", dragKg: 11.9, retrieveSpeed: 6, smoothness: 7, durability: 127, price: 19822, sprite: "h9.png", emoji: "⚙️", description: "Профессиональная катушка для крупной рыбы. Непревзойдённая плавность работы. Уровень 9." },
  { tier: 10, name: "Катушка Морская", dragKg: 13.7, retrieveSpeed: 7, smoothness: 8, durability: 137, price: 28590, sprite: "h10.png", emoji: "⚙️", description: "Морская катушка с высокой мощностью. Отличный контроль при вываживании крупной рыбы. Уровень 10." },
  { tier: 11, name: "Катушка Морская Pro", dragKg: 15.1, retrieveSpeed: 7, smoothness: 8, durability: 148, price: 35092, sprite: "h11.png", emoji: "⚙️", description: "Усиленная морская катушка. Плавная работа в условиях экстремальных нагрузок. Уровень 11." },
  { tier: 12, name: "Катушка Морская Heavy", dragKg: 17.3, retrieveSpeed: 8, smoothness: 9, durability: 159, price: 42310, sprite: "h12.png", emoji: "⚙️", description: "Прочная морская катушка. Максимальный контроль мощных рывков. Уровень 12." },
  { tier: 13, name: "Катушка Морская X-Heavy", dragKg: 25.9, retrieveSpeed: 9, smoothness: 10, durability: 191, price: 99, currency: "iap", sprite: "h13.png", emoji: "⚙️", description: "Катушка премиального качества сверхвысокой мощности. Непревзойдённая плавность и контроль для экстремальной океанической рыбалки." },
  { tier: 14, name: "Катушка Океан Pro", dragKg: 22.3, retrieveSpeed: 9, smoothness: 10, durability: 181, price: 58937, sprite: "h14.png", emoji: "⚙️", description: "Профессиональная океаническая катушка. Идеальная плавность для трофейной рыбалки. Уровень 14." },
  { tier: 15, name: "Катушка Океан X-Pro", dragKg: 25.9, retrieveSpeed: 9, smoothness: 10, durability: 191, price: 68361, sprite: "h15.png", emoji: "⚙️", description: "Экстра-мощная океаническая катушка. Непревзойдённый контроль крупнейших хищников. Уровень 15." },
  { tier: 16, name: "Катушка Титан", dragKg: 29.5, retrieveSpeed: 10, smoothness: 10, durability: 202, price: 78536, sprite: "h16.png", emoji: "⚙️", description: "Титановая катушка для экстремальной рыбалки. Максимальная плавность и мощность. Уровень 16." },
  { tier: 17, name: "Катушка Легенда", dragKg: 37.4, retrieveSpeed: 10, smoothness: 10, durability: 223, price: 119, currency: "iap", sprite: "h17.png", emoji: "⚙️", description: "Легендарная катушка премиального качества. Максимальная мощность и идеальная плавность для трофейной океанической рыбалки." },
  { tier: 18, name: "Катушка Акула", dragKg: 37.4, retrieveSpeed: 10, smoothness: 10, durability: 223, price: 101169, sprite: "h18.png", emoji: "⚙️", description: "Непревзойдённая катушка для ловли акул. Максимальная мощность и надёжность. Уровень 18." }
];

// Функция для получения требуемого уровня игрока для tier'а снасти
function getRequiredLevelForTier(tier) {
  // Ярусная система: tier 1-18 распределены на уровни 1-100
  // Tier 1-3: Уровни 1-15 (Новичок)
  // Tier 4-6: Уровни 16-30 (Опытный)
  // Tier 7-9: Уровни 31-45 (Профи)
  // Tier 10-12: Уровни 46-60 (Мастер)
  // Tier 13-15: Уровни 61-80 (Эксперт)
  // Tier 16-18: Уровни 81-100 (Легенда)
  
  const tierLevels = {
    1: 1,
    2: 6,
    3: 11,
    4: 16,
    5: 21,
    6: 26,
    7: 31,
    8: 36,
    9: 41,
    10: 46,
    11: 51,
    12: 56,
    13: 61,
    14: 68,
    15: 75,
    16: 82,
    17: 90,
    18: 95
  };
  
  return tierLevels[tier] || 1;
}

// Экспорт всех баз данных
if (typeof module !== 'undefined' && module.exports) {
  module.exports = {
    RODS_DATABASE,
    LINES_DATABASE,
    FLOATS_DATABASE,
    HOOKS_DATABASE,
    REELS_DATABASE,
    getRequiredLevelForTier
  };
}

// Вспомогательные функции для работы со снастями
const GearDB = {
  // Удочки
  getRodByTier: (tier) => RODS_DATABASE.find(rod => rod.tier === tier),
  getRodsUpToTier: (tier) => RODS_DATABASE.filter(rod => rod.tier <= tier),
  
  // Лески
  getLineByTier: (tier) => LINES_DATABASE.find(line => line.tier === tier),
  getLinesUpToTier: (tier) => LINES_DATABASE.filter(line => line.tier <= tier),
  
  // Поплавки
  getFloatByTier: (tier) => FLOATS_DATABASE.find(float => float.tier === tier),
  getFloatsUpToTier: (tier) => FLOATS_DATABASE.filter(float => float.tier <= tier),
  
  // Крючки
  getHookByTier: (tier) => HOOKS_DATABASE.find(hook => hook.tier === tier),
  getHooksUpToTier: (tier) => HOOKS_DATABASE.filter(hook => hook.tier <= tier),
  
  // Катушки
  getReelByTier: (tier) => REELS_DATABASE.find(reel => reel.tier === tier),
  getReelsUpToTier: (tier) => REELS_DATABASE.filter(reel => reel.tier <= tier),
  
  // Общие
  getMaxTier: () => 18,
  
  // Расчет общей силы снастей
  calculateTotalPower: (rodTier, lineTier, floatTier, hookTier, reelTier) => {
    const rod = GearDB.getRodByTier(rodTier);
    const line = GearDB.getLineByTier(lineTier);
    const hook = GearDB.getHookByTier(hookTier);
    const reel = GearDB.getReelByTier(reelTier);
    
    if (!rod || !line || !hook || !reel) return 0;
    
    return Math.min(
      rod.powerCap,
      line.testKg * 5, // Примерный коэффициент
      hook.holdBonus * 10,
      reel.dragKg * 7
    );
  },
  
  // Получить локализованное название снасти
  getLocalizedGearName: (type, tier, defaultName) => {
    if (window.localizationSystem) {
      return window.localizationSystem.getGearName(type, tier, defaultName);
    }
    return defaultName;
  },
  
  // Получить локализованное описание снасти
  getLocalizedGearDescription: (type, tier, defaultDescription) => {
    if (window.localizationSystem) {
      return window.localizationSystem.getGearDescription(type, tier, defaultDescription);
    }
    return defaultDescription;
  }
};

if (typeof module !== 'undefined' && module.exports) {
  module.exports.GearDB = GearDB;
}

// Экспортируем в window для доступа из других модулей
if (typeof window !== 'undefined') {
  window.GearDB = GearDB;
}
