// -*- coding: utf-8 -*-
// База данных хлама и сокровищ
// Можно поймать вместо рыбы
// Динамическая система: предметы сами определяют, где они могут появиться

const JUNK_DATABASE = [
  {
    id: 1,
    name: "Ржавая гайка",
    category: "Мусор",
    sellPrice: 5,
    sprite: "g1.png",
    emoji: "🔩",
    description: "Старая металлическая гайка, покрытая ржавчиной. Когда-то была частью какого-то механизма, но теперь валяется на дне водоёма.",
    // Динамическая система
    zones: [1, 2, 3, 4, 5, 6],  // Доступна в начальных зонах
    baseChance: 0.30,            // Базовый шанс 30% (от общего шанса мусора)
    chanceModifier: {            // Модификаторы по зонам
      1: 2.0,   // В зоне 1 шанс x2.0 (60%)
      2: 1.8,   // В зоне 2 шанс x1.8 (54%)
      3: 1.5,   // В зоне 3 шанс x1.5 (45%)
      4: 1.2,   // В зоне 4 шанс x1.2 (36%)
      5: 0.8,   // В зоне 5 шанс x0.8 (24%)
      6: 0.5    // В зоне 6 шанс x0.5 (15%)
    }
  },
  {
    id: 2,
    name: "Жестяная банка",
    category: "Мусор",
    sellPrice: 8,
    sprite: "g2.png",
    emoji: "🥫",
    description: "Пустая консервная банка без этикетки. Видимо, кто-то не очень заботился об экологии и выбросил её прямо в воду.",
    zones: [1, 2, 3, 4, 5, 6, 7],
    baseChance: 0.25,
    chanceModifier: {
      1: 1.8,
      2: 1.6,
      3: 1.4,
      4: 1.2,
      5: 1.0,
      6: 0.7,
      7: 0.4
    }
  },
  {
    id: 3,
    name: "Старый сапог",
    category: "Мусор",
    sellPrice: 12,
    sprite: "g3.png",
    emoji: "👢",
    description: "Потёртый кожаный сапог, потерявший свою пару. Интересно, как он попал в воду? Может быть, его владелец поскользнулся на берегу?",
    zones: [1, 2, 3, 4, 5, 6, 7, 8],
    baseChance: 0.20,
    chanceModifier: {
      1: 1.5,
      2: 1.4,
      3: 1.3,
      4: 1.2,
      5: 1.0,
      6: 0.8,
      7: 0.6,
      8: 0.3
    }
  },
  {
    id: 4,
    name: "Ржавая блесна",
    category: "Мусор",
    sellPrice: 20,
    sprite: "g4.png",
    emoji: "🎣",
    description: "Старая рыболовная блесна, потерявшая свой блеск. Видимо, кто-то из рыбаков зацепился за корягу и потерял свою приманку.",
    zones: [3, 4, 5, 6, 7, 8, 9, 10],
    baseChance: 0.18,
    chanceModifier: {
      3: 1.8,
      4: 1.6,
      5: 1.4,
      6: 1.2,
      7: 1.0,
      8: 0.8,
      9: 0.5,
      10: 0.3
    }
  },
  {
    id: 5,
    name: "Сломанный телефон",
    category: "Мусор",
    sellPrice: 80,
    sprite: "g5.png",
    emoji: "📱",
    description: "Старый мобильный телефон с треснувшим экраном. Наверное, упал в воду во время селфи на берегу. Теперь он точно не включится.",
    zones: [7, 8, 9, 10, 11, 12],
    baseChance: 0.15,
    chanceModifier: {
      7: 1.5,
      8: 1.4,
      9: 1.2,
      10: 1.0,
      11: 0.7,
      12: 0.4
    }
  },
  {
    id: 6,
    name: "Потерянные часы",
    category: "Редкость",
    sellPrice: 220,
    sprite: "g6.png",
    emoji: "⌚",
    description: "Элегантные наручные часы с кожаным ремешком. Хотя механизм заржавел, корпус ещё в неплохом состоянии. Кто-то очень расстроился, потеряв их.",
    zones: [8, 9, 10, 11, 12, 13, 14],
    baseChance: 0.12,
    chanceModifier: {
      8: 1.3,
      9: 1.2,
      10: 1.1,
      11: 1.0,
      12: 0.9,
      13: 0.7,
      14: 0.5
    }
  },
  {
    id: 7,
    name: "Кольцо/украшение",
    category: "Сокровище",
    sellPrice: 750,
    sprite: "g7.png",
    emoji: "💍",
    description: "Красивое золотое кольцо с небольшим камнем. Возможно, это было обручальное кольцо или семейная реликвия. Настоящая находка для коллекционера!",
    zones: [10, 11, 12, 13, 14, 15, 16],
    baseChance: 0.10,
    chanceModifier: {
      10: 1.2,
      11: 1.1,
      12: 1.0,
      13: 0.9,
      14: 0.8,
      15: 0.7,
      16: 0.5
    }
  },
  {
    id: 8,
    name: "Старинная монета",
    category: "Сокровище",
    sellPrice: 1400,
    sprite: "g8.png",
    emoji: "🪙",
    description: "Древняя монета с едва различимыми символами. Возможно, она пролежала на дне водоёма несколько веков. Антиквары заплатят за неё хорошие деньги.",
    zones: [13, 14, 15, 16, 17, 18],
    baseChance: 0.08,
    chanceModifier: {
      13: 1.2,
      14: 1.1,
      15: 1.0,
      16: 0.9,
      17: 0.8,
      18: 0.6
    }
  },
  {
    id: 9,
    name: "Кулон с гравировкой",
    category: "Сокровище",
    sellPrice: 2200,
    sprite: "g8.png",
    emoji: "📿",
    description: "Изящный серебряный кулон с выгравированными инициалами и датой. Это явно было дорого сердцу владельца. Настоящее сокровище с историей.",
    zones: [15, 16, 17, 18, 19, 20],
    baseChance: 0.06,
    chanceModifier: {
      15: 1.3,
      16: 1.2,
      17: 1.1,
      18: 1.0,
      19: 0.9,
      20: 0.8
    }
  }
];

// Конфигурация общего шанса выпадения предметов по зонам
const JUNK_ZONE_CHANCE = {
  1: 0.10,   // 10% - обычный шанс
  2: 0.10,   // 10%
  3: 0.09,   // 9%
  4: 0.09,   // 9%
  5: 0.08,   // 8%
  6: 0.08,   // 8%
  7: 0.07,   // 7%
  8: 0.07,   // 7%
  9: 0.06,   // 6%
  10: 0.06,  // 6%
  11: 0.06,  // 6%
  12: 0.05,  // 5%
  13: 0.05,  // 5%
  14: 0.05,  // 5%
  15: 0.04,  // 4%
  16: 0.04,  // 4%
  17: 0.04,  // 4%
  18: 0.03,  // 3%
  19: 0.03,  // 3%
  20: 0.03   // 3% - финальная зона
};

// Экспорт
if (typeof module !== 'undefined' && module.exports) {
  module.exports = { JUNK_DATABASE, JUNK_ZONE_CHANCE };
}

// Вспомогательные функции
const JunkDB = {
  // Получить предмет по ID
  getById: (id) => JUNK_DATABASE.find(item => item.id === id),
  
  // Получить предметы по категории
  getByCategory: (category) => JUNK_DATABASE.filter(item => item.category === category),
  
  // Получить предметы доступные в зоне
  getByZone: (zoneId) => JUNK_DATABASE.filter(item => item.zones && item.zones.includes(zoneId)),
  
  // Получить случайный предмет (старая функция для совместимости)
  getRandomJunk: () => JUNK_DATABASE[Math.floor(Math.random() * JUNK_DATABASE.length)],
  
  // Получить общее количество предметов
  getTotalCount: () => JUNK_DATABASE.length,
  
  // НОВАЯ ФУНКЦИЯ: Попытка поймать предмет в зоне
  tryGetJunkFromZone: (zoneId) => {
    // Получаем общий шанс выпадения для зоны
    const zoneChance = JUNK_ZONE_CHANCE[zoneId] || 0.05;
    
    // Проверяем, выпадет ли вообще предмет
    const randomRoll = Math.random();
    
    if (randomRoll > zoneChance) {
      return null; // Предмет не выпал
    }
    
    // Получаем доступные предметы в этой зоне
    const availableItems = JUNK_DATABASE.filter(item => 
      item.zones && item.zones.includes(zoneId)
    );
    
    if (availableItems.length === 0) {
      return null; // Нет доступных предметов
    }
    
    // Вычисляем веса для каждого предмета с учётом модификаторов
    const weightedItems = availableItems.map(item => {
      const modifier = item.chanceModifier && item.chanceModifier[zoneId] 
        ? item.chanceModifier[zoneId] 
        : 1.0;
      const weight = item.baseChance * modifier;
      return {
        item: item,
        weight: weight
      };
    });
    
    // Выбираем предмет по весам
    const totalWeight = weightedItems.reduce((sum, wi) => sum + wi.weight, 0);
    let random = Math.random() * totalWeight;
    
    for (const weightedItem of weightedItems) {
      random -= weightedItem.weight;
      if (random <= 0) {
        return weightedItem.item;
      }
    }
    
    // Fallback: вернуть первый предмет
    return weightedItems[0].item;
  },
  
  // НОВАЯ ФУНКЦИЯ: Получить шанс выпадения предмета в зоне (для отладки/UI)
  getJunkChanceInZone: (zoneId) => {
    const zoneChance = JUNK_ZONE_CHANCE[zoneId] || 0.05;
    const availableItems = JUNK_DATABASE.filter(item => 
      item.zones && item.zones.includes(zoneId)
    );
    
    return {
      totalChance: zoneChance,
      itemCount: availableItems.length,
      items: availableItems.map(item => {
        const modifier = item.chanceModifier && item.chanceModifier[zoneId] 
          ? item.chanceModifier[zoneId] 
          : 1.0;
        return {
          id: item.id,
          name: item.name,
          relativeChance: item.baseChance * modifier,
          category: item.category,
          sellPrice: item.sellPrice
        };
      })
    };
  },
  
  // НОВАЯ ФУНКЦИЯ: Получить статистику по всем зонам (для отладки)
  getZoneStatistics: () => {
    const stats = {};
    
    for (let zoneId = 1; zoneId <= 20; zoneId++) {
      stats[zoneId] = JunkDB.getJunkChanceInZone(zoneId);
    }
    
    return stats;
  },
  
  // Функция для дебаг панели - принудительно выбирает случайный предмет из зоны
  getRandomJunkFromZone: (zoneId) => {
    const availableItems = JUNK_DATABASE.filter(item => 
      item.zones && item.zones.includes(zoneId)
    );
    
    if (availableItems.length === 0) {
      return null;
    }
    
    return availableItems[Math.floor(Math.random() * availableItems.length)];
  }
};

if (typeof module !== 'undefined' && module.exports) {
  module.exports.JunkDB = JunkDB;
}
